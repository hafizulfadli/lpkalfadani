@include('user.layout.header')
@include('user.layout.sidebar')
@yield('content')
@include('user.layout.footer')

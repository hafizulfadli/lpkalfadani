<?php $__env->startSection('title','Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header pb-0">
            <div class="d-flex align-items-center">
              <p class="mb-0">Detail Page</p>
            </div>
          </div>
          <div class="card-body">
            <ul class="list-group">
                <li class="list-group-item border-0 d-flex p-4 mb-2 bg-gray-100 border-radius-lg">
                  <div class="d-flex flex-column">
                    <h4 class="mb-2"><?php echo e($page->judul); ?></h4>
                    <div style="display: flex;">
                        <div style="display: flex; align-items: center; margin-left: 10px;">
                          <i class="fa fa-eye fa-sm" style="margin-right: 5px;"></i>
                          <span><?php echo e($page->dilihat); ?></span>
                        </div>
                        <div style="display: flex; align-items: center; margin-left: 10px;">
                          <i class="fa fa-page fa-sm" style="margin-right: 5px;"></i>
                          <span><?php echo e($page->title); ?></span>
                        </div>
                      </div>
                    <span class="mb-2 text-sm mt-1"><?php echo $page->konten; ?></span>
                  </div>
                  <div class="ms-auto text-end">
                    <img src="<?php echo e(url('thumbnail/'.$page->thumbnail)); ?>" widht="200px" height="150px"  alt="" srcset="">
                  </div>
                </li>
            </ul>
            <a href="/page" class="btn btn-dark btn-sm ms-auto mt-2">Kembali</a>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mediatama\project\alfadani\resources\views/admin/page/show.blade.php ENDPATH**/ ?>
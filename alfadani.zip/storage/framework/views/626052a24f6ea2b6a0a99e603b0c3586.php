<?php $__env->startSection('title','Profil'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="bg-[url(<?php echo e('/images/hero2.jpg'); ?>)] sm:bg-white object-cover bg-cover bg-center">
        <div class="py-8 sm:py-12 flex flex-col gap-8 md:gap-16">
            <div class="container flex flex-col gap-8 md:gap-16">
                <h1 class="font-semibold text-2xl sm:text-4xl xl:text-5xl text-hijau-unand flex items-center justify-center gap-2 my-36">Sambutan</h1>
            </div>
        </div>
    </div>
    <div class="container my-20">
        <?php $__currentLoopData = $sambutan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col md:flex-row justify-between gap-4 md:gap-20 mx-4">
            <img src="<?php echo e(url('thumbnail/',$data->image)); ?>" class="rounded-2xl w-full md:w-2/5 bg-cover object-cover">
            <div class="flex flex-col gap-4 md:gap-12 w-full md:w-3/5 my-4 md:my-24">
                <h1 class="text-almost-black text-4xl md:text-6xl font-semibold"><?php echo e($data->title); ?></h1>
                <p class="text-almost-black text-xl font-medium"><?php echo $data->konten; ?></p>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mediatama\project\alfadani\resources\views/user/sambutan/sambutan.blade.php ENDPATH**/ ?>
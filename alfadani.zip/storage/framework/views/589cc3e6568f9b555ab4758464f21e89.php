<?php $__env->startSection('title','Detail Berita'); ?>
<?php $__env->startSection('content'); ?>
<main>
    <div class="container my-28 flex flex-col md:flex-row justify-between gap-8 px-4">
        <div class="flex flex-col rounded-3xl shadow-lg w-full md:w-3/4">
            <div class="flex items-start justify-center flex-col gap-4 p-4">
                <div class="flex items-start py-2">
                    <svg xmlns="http://www.w3.org/2000/svg" width="166" height="6" viewBox="0 0 166 6" fill="none" class="">
                        <path d="M3 3H83H163" stroke="#872341" stroke-width="6" stroke-linecap="round"/>
                    </svg>
                </div>
                <h1 class="font-medium text-4xl text-almost-black"><?php echo e($detailberita->title); ?></h1>
                <h5 class="font-normal text-base text-gray-500">Padang, <?php echo e(date('d F Y ', strtotime($detailberita->tanggal))); ?></h5>
            </div>
            <div class="flex flex-col gap-8 p-4 w-full">
        <img src="<?php echo e(url('thumbnail/',$detailberita->thumbnail)); ?>" class="w-full h-[600px]">
                <p class="font-medium text-lg text-almost-black"><?php echo $detailberita->kontent; ?></p>
                <iframe class="-mt-10" width="100%" height="350" src="<?php echo e($detailberita->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            </div>
        </div>
        <div class="flex flex-col rounded-3xl shadow-lg w-full md:w-1/4 gap-4 p-4 pt-8">
            <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="166" height="6" viewBox="0 0 166 6" fill="none">
                    <path d="M3 3H83H163" stroke="#872341" stroke-width="6" stroke-linecap="round"/>
                </svg>
               <h2 class="uppercase py-4 text-yellow text-3xl font-semibold">Berita Lainnya</h2>
            </div>
            <div class="flex flex-col gap-4">
                  <?php $__currentLoopData = $berita1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col gap-2">
                    <img src="<?php echo e(url('thumbnail/',$data->thumbnail)); ?>" class="rounded w-[full] h-[170px] object-cover bg-cover bg-center">
                    <div class="flex flex-col gap-1">
                        <a href="<?php echo e(route('detailberita',$data->slug)); ?>"> <h5 class="font-medium text-lg pb-1"><?php echo e($data->title); ?></h5></a>
                        <p class="font-normal text-sm">
                            <?php echo \Illuminate\Support\Str::limit($data->kontent, 100, '...'); ?>

                        </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mediatama\project\alfadani\resources\views/user/home/detail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Detail'); ?>
<?php $__env->startSection('content'); ?>
<main>
  <div class="container my-28 flex flex-row justify-between gap-8">
    <div class="flex flex-col rounded-3xl shadow-lg w-3/4">
      <div class="flex items-start justify-center flex-col gap-4 p-4">
        <div class="flex items-start py-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="166" height="6" viewBox="0 0 166 6" fill="none" class="w-1/2 lg:w-full">
            <path d="M3 3H83H163" stroke="#872341" stroke-width="6" stroke-linecap="round" />
          </svg>
        </div>
        <h1 class="font-medium text-4xl text-almost-black"><?php echo e($page->judul); ?></h1>
        <h5 class="font-normal text-base text-gray-500">Padang, <?php echo e(date('d F Y ', strtotime($page->tanggal))); ?></h5>
      </div>
      <div class="flex flex-col gap-8 p-4 w-full">
        <img src="<?php echo e(url('thumbnail/',$page->thumbnail)); ?>" class="w-full">
        <p class="font-medium text-lg text-almost-black"><?php echo $page->konten; ?></p>
      </div>
    </div>
    <div class="flex flex-col rounded-3xl shadow-lg w-1/4 gap-4 p-4 pt-8">
      <div>
        <svg xmlns="http://www.w3.org/2000/svg" width="166" height="6" viewBox="0 0 166 6" fill="none">
          <path d="M3 3H83H163" stroke="#872341" stroke-width="6" stroke-linecap="round" />
        </svg>
        <h2 class="uppercase py-4 text-yellow text-3xl font-semibold">Berita Lainnya</h2>
      </div>
      <div class="flex flex-col gap-4">
        <?php $__currentLoopData = $beritapopuler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col gap-2">
            <img src="<?php echo e(url('thumbnail/',$data->thumbnail)); ?>" class="rounded w-[full] h-[160px] object-cover bg-cover bg-center">
            <div class="flex flex-col gap-1">
                <a href="<?php echo e(route('detailberita',$data->slug)); ?>"> <h5 class="font-medium text-lg pb-1"><?php echo e($data->title); ?></h5></a>
                <p class="font-normal text-sm">
                    <?php echo \Illuminate\Support\Str::limit($data->kontent, 100, '...'); ?>

                </p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mediatama\project\alfadani\resources\views/user/landing_page/detail.blade.php ENDPATH**/ ?>
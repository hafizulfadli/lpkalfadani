<?php $__env->startSection('title','Program'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header pb-0">
            <div class="d-flex align-items-center">
              <p class="mb-0">Data Program</p>
              <a href="<?php echo e(route('program.create')); ?>" class="btn btn-primary btn-sm ms-auto">Tambah</a>
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
                <table id="example" class="table align-items-center mb-0">
                    <thead>
                      <tr>
                        <th width="5%" class="text-uppercase text-secondary text-xs font-weight-bolder opacity-10" style="text-align: center;">#</th>
                        <th class="text-uppercase text-secondary text-xs font-weight-bolder opacity-10">Title</th>
                        <th width="25%" class="text-uppercase text-secondary text-xs font-weight-bolder opacity-10" style="text-align: center;">Image</th>
                        <th width="25%" class="text-uppercase text-secondary text-xs font-weight-bolder opacity-10" style="text-align: center;">Aksi</th>
                      </tr>
                    </thead>
                   <tbody>
                    <?php $__currentLoopData = $program; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td  align="center"><?php echo e($loop->iteration); ?></td>
                        <td ><?php echo e($data->title); ?></td>
                        <td align="center">
                    <img src="<?php echo e(url('thumbnail/'.$data->image)); ?>" alt="" srcset="" style="width: 120px; height: 100px;">

                        </td>
                        <td align="center">
                            <a href="<?php echo e(route('program.show',$data->id)); ?>" class="btn btn-link text-success text-gradient px-1 mb-0" ><i class="fa fa-eye me-2 "></i></a>
                            <a href="<?php echo e(route('program.edit',$data->id)); ?>" class="btn btn-link text-primary text-gradient px-1 mb-0" ><i class="fas fa-pencil-alt text-dark me-2"></i></a>
                            <a href="<?php echo e(route('program.destroy',$data->id)); ?>" onclick="event.preventDefault(); confirm('Apa ingin menghapus data ini?') ? document.getElementById('delete-form-<?php echo e($data->id); ?>').submit() : false;" class="btn btn-link text-danger text-gradient px-1 mb-0" ><i class="far fa-trash-alt text-dark me-2"></i></a>
                            <form id="delete-form-<?php echo e($data->id); ?>" action="<?php echo e(route('program.destroy', $data->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                  </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\mediatama\project\alfadani\resources\views/admin/program/program.blade.php ENDPATH**/ ?>